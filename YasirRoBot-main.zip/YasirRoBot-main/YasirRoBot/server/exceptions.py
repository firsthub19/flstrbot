class InvalidHash(Exception):
    message = "Invalid hash/Hash tidak valid"


class FIleNotFound(Exception):
    message = "File not found/File tidak ditemukan"
